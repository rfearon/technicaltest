package cucumberTest;

import cucumber.api.java.en.And;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;

public class technicalTest {
    WebDriver driver = new FirefoxDriver();

    @Test
    @Given("^I have opened the browser$")
    public void openBrowser() {
        driver = new FirefoxDriver();
    }

    @Test
    @When("^I open the QAWorks website$")
    public void goToQAWorks() {
        driver.navigate().to("http://www.qaworks.com/contact.aspx");
    }

    @Test
    @Then("^should be able to enter the following information$")
    public void shouldBeAbleToEnterTheFollowingInformationNameEmailMessage()  {
        // Write code here that turns the phrase above into concrete actions
        WebElement name = driver.findElement(By.id("ctl00_MainContent_NameBox"));
        name.sendKeys("j.Bloggs");
        WebElement email = driver.findElement(By.id("ctl00_MainContent_EmailBox"));
        email.sendKeys("j.Bloggs@qaworks.com");
        WebElement message = driver.findElement(By.id("ctl00_MainContent_MessageBox"));
        message.sendKeys("please contact me I want to find out more");
    }


    @Test
    @And("^hit the send button$")
    public void hitTheSendButton() throws Throwable {
        driver.findElement(By.id("ctl00_MainContent_SendButton")).click();
    }
}
